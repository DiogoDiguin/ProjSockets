package udp.bidirecional;

import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import javax.swing.JTextArea;

public class ClienteServidor extends Thread {

    private final int PORTA_IN;
    private final int PORTA_OUT;
    private final String HOST;
    private final JTextArea txt;

    public ClienteServidor(String HOST, int PORTA_IN, int PORTA_OUT, JTextArea txt) {
        this.HOST = HOST;
        this.PORTA_IN = PORTA_IN;
        this.PORTA_OUT = PORTA_OUT;
        this.txt = txt;
        txt.append("Iniciado\n");
    }

    public void enviar(String msg) {
        try {
            byte[] buffer = msg.getBytes();
            DatagramPacket pct = new DatagramPacket(
                    buffer,
                    buffer.length,
                    InetAddress.getByName(HOST),
                    PORTA_OUT
            );
            new DatagramSocket().send(pct);

            txt.append("MSG: " + msg + "\n\n");

        } catch (Exception e) {
            txt.append("\nERRO: " + e.getMessage() + "\n");
        }
    }

    @Override
    public void run() {
        try {
            DatagramSocket srv = new DatagramSocket(PORTA_IN);

            while (true) {
                byte[] buffer = new byte[256];
                DatagramPacket pct = new DatagramPacket(
                        buffer,
                        buffer.length
                );

                srv.receive(pct);
                String msg = new String(pct.getData()).trim();
                txt.append("DE: " + pct.getAddress().getHostAddress() + "\n");
                txt.append("MSG: " + msg + "\n\n");
            }

        } catch (Exception e) {
            txt.append("\nERRO: " + e.getMessage() + "\n");
        }
    }

}
